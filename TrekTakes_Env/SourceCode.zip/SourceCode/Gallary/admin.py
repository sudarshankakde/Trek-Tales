from django.contrib import admin

# Register your models here.
from Gallary.models import Memories
admin.site.register(Memories)

