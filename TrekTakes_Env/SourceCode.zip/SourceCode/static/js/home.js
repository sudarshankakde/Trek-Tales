document.getElementsByTagName("img").classList.add('img-fluid');


