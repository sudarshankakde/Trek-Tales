﻿# Installation & Usage
**Step 1: Install [Python3](https://www.python.org/downloads/) From there Site.**

**Step 2:Download Repository From [GitHub](https://github.com/sudarshankakde).**

**Step 3:Open Command Prompt in Project Repository.**

**Step 4:Type Command**
> `python3 -m pip install -r requirements.txt` 
> **All dependency for  project will get installed.**

**Step 5:Start Django Server**

> `python manage.py runserver`
> **It will start Django Server on localhost:8000**




## About Company
**Treak Tales.
It is a start up based in Aurangabad, which provides trips and allows you to customize your own journey based on themes**


## About Us
**Team Members**
 1. [Sudarshan Kakde](https://github.com/sudarshankakde) 
 2. Avishkar Aher
 3. Ankita Jadhao
 4. Rushali Jadhav
 5. Pooja Dhage
 6. Aniket Mahule




##Some Steps Should DO
1- change data related Tiwilo number Gmail etc in setting folder.

2- check for stmp enable in gmail













